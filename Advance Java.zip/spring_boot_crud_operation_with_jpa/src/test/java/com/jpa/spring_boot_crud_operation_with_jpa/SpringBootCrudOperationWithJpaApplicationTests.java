package com.jpa.spring_boot_crud_operation_with_jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCrudOperationWithJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
