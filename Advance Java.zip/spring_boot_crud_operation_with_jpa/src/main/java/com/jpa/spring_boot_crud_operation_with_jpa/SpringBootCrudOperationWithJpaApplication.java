package com.jpa.spring_boot_crud_operation_with_jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCrudOperationWithJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCrudOperationWithJpaApplication.class, args);
	}

}
